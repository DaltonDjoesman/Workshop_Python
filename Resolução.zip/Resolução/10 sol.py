sala = {"lulu": 19, "juju": 17, "lolo": 18}

media = 0
for valor in sala.keys():
  media += sala[valor]

print(f"A média da sala é: {media/len(sala.keys())} valores")