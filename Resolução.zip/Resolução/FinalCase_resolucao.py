suspeitos = [
    {"nome": "Alice", "alibi": "estava no cinema", "impressao": "A123"},
    {"nome": "Bruno", "alibi": "tomava café no centro", "impressao": "B456"},
    {"nome": "Carla", "alibi": "fazendo compras no mercado", "impressao": "C789"}
]

# Impressões encontradas na cena (pode ter mais de uma)
evidencias = ["B456", "C789", "C789", "X000"]

def filtrar_por_alibi(suspeitos, texto):
    # TODO: implementar
    pessoas = []
    for sus in suspeitos:
        if sus["alibi"].count(texto) > 0:
            pessoas.append(sus["nome"])
    return pessoas     

def contar_pistas(evidencias):
    # TODO: implementar
    quantidade = {}
    for x in evidencias:
        quantidade[x] = evidencias.count(x)

    return quantidade

def identificar_suspeito(suspeitos, pistas_contadas):
    # TODO: implementar
    maior = max(pistas_contadas.items())
    for i in pistas_contadas.keys():
        if pistas_contadas[i] == maior[1]:
            for j in suspeitos:
                if j["impressao"] == i:
                    return j["nome"]
                
    return "Desconhecido"

def relatorio_final(suspeitos, evidencias):
    pistas_contadas = contar_pistas(evidencias)
    suspeitos_filtrados = filtrar_por_alibi(suspeitos, "cinema")
    culpado = identificar_suspeito(suspeitos, pistas_contadas)

    print("Pistas encontradas:")
    for imp, qt in pistas_contadas.items():
        print(f"  {imp} → {qt} vez{'es' if qt>1 else ''}")
    print()
    print(f"Suspeitos com “cinema” no álibi: {suspeitos_filtrados}")
    print()
    print(f"Culpado provável: {culpado}")

# Executar o relatório
relatorio_final(suspeitos, evidencias)

