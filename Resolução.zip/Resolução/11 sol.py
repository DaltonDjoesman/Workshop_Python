def media (sala):
  media = 0
  for valor in sala.keys():
    media += sala[valor]
  
  return media/len(sala.keys())


sala = {"lulu": 19, "juju": 17, "lolo": 18}

print(f"Média anterior: {media(sala)} valores")

sala["val"] = 17

print(f"Media posterior: {media(sala)} valores")