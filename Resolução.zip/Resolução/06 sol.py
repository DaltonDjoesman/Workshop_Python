num = 0
while (num < 10):
   num = num + 1
   print(num)
final = num
print(final)

######################

num = 0
while True:
   num = num + 1
   print(num)
   if (num == 10):
       break
final = num
print(final)