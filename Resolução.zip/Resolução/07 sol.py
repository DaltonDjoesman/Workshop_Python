for num in range(10):
    print(num)

for num in range(5, 15, 2):
    print(num)